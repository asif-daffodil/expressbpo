<div class="container-fluid services">
    <div class="container">
        <div class="row py-5">
            <div class="col-md-4 wow fadeInLeft">
                <div>
                    <h4 class="text-success p-0 m-0">Broad Knowledge Base</h4>
                    <h2 class="display-4 text-blue p-o m-0">Industries <br> We Serve</h2>
                </div>
            </div>
            <div class="col-md-8 d-flex align-items-center wow fadeInRight">
                NEXUSBPO is an outsourced accounting service provider that works with clients across a diverse range
                of industries. Our team of experienced accounting professionals has a deep understanding of the unique
                financial challenges faced by businesses in various industries, and we tailor our services to meet the
                specific needs of each client.
            </div>
        </div>
        <div class="row py-5 d-none d-lg-flex">
            <div class="col-md-3">
                <div class="border-top py-3 wow fadeInLeft">
                    <ul class="nav flex-column clientList">
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Website
                                Development</a>
                        </li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Website
                                Maintaining</a></li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Digital
                                Marketing</a></li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">ERP Maintaining</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border-top py-3 wow fadeInLeft">
                    <ul class="nav flex-column clientList">
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">IT Services</a></li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Video Editing</a>
                        </li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Bookkeeping</a></li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Accounts Payable</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border-top py-3 wow fadeInDown">
                    <ul class="nav flex-column clientList">
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Accounts
                                Receivable</a></li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Inventory
                                Management</a></li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Payroll
                                Management</a></li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Sale Tax
                                Compliance</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border-top py-3 wow fadeInRight">
                    <ul class="nav flex-column clientList">
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Reporting</a></li>
                        <li class="nav-item"><a href="" class="nav-link ps-0 fs-5 text-dark">Quickbooks
                                Accounting</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row py-5">
            <a class="col-md-4 text-decoration-none" href="">
                <div class="text-center">
                    <figure>
                        <img loading="lazy" decoding="async" fetchpriority="high"
                            src="<?php echo e(asset('images/for-us-based-cpa-firms.webp')); ?>" alt=""
                            class="img-fluid shadow shadow-md w-100" style="height: 224px; object-fit: cover;">
                    </figure>
                    <h3 class="text-uppercase text-blue mt-3 mb-0 h5 mb-5">Website Development</h3>
                </div>
            </a>
            <a class="col-md-4 text-decoration-none" href="">
                <div class="text-center">
                    <figure>
                        <img loading="lazy" decoding="async" fetchpriority="high"
                            src="<?php echo e(asset('images/for-us-based-ecommerce-companies.webp')); ?>" alt=""
                            class="img-fluid shadow shadow-md w-100" style="height: 224px; object-fit: cover;">
                    </figure>
                    <h3 class="text-uppercase text-blue mt-3 mb-0 h5 mb-5">Website Maintaining</h3>
                </div>
            </a>
            <a class="col-md-4 text-decoration-none" href="">
                <div class="text-center">
                    <figure>
                        <img loading="lazy" decoding="async" fetchpriority="high"
                            src="<?php echo e(asset('images/for-us-based-wireless-companies.png')); ?>" alt=""
                            class="img-fluid shadow shadow-md w-100" style="height: 224px; object-fit: cover;">
                    </figure>
                    <h3 class="text-uppercase text-blue mt-3 mb-0 h5 mb-5">IT Services</h3>
                </div>
            </a>
            <a class="col-md-4 text-decoration-none" href="">
                <div class="text-center">
                    <figure>
                        <img loading="lazy" decoding="async" fetchpriority="high"
                            src="<?php echo e(asset('images/for-us-based-companies-using-netsuite-sap-erp-system.webp')); ?>"
                            alt="" class="img-fluid shadow shadow-md w-100"
                            style="height: 224px; object-fit: cover;">
                    </figure>
                    <h3 class="text-uppercase text-blue mt-3 mb-0 h5 mb-5">Digital Marketing</h3>
                </div>
            </a>
            <a class="col-md-4 text-decoration-none" href="">
                <div class="text-center">
                    <figure>
                        <img loading="lazy" decoding="async" fetchpriority="high"
                            src="<?php echo e(asset('images/for-us-based-fundmanagers-and-vc-firms.jpg')); ?>" alt=""
                            class="img-fluid shadow shadow-md w-100" style="height: 224px; object-fit: cover;">
                    </figure>
                    <h3 class="text-uppercase text-blue mt-3 mb-0 h5 mb-5">SEO</h3>
                </div>
            </a>
            <a class="col-md-4 text-decoration-none" href="">
                <div class="text-center">
                    <figure>
                        <img loading="lazy" decoding="async" fetchpriority="high"
                            src="<?php echo e(asset('images/video-editing.jpg')); ?>" alt=""
                            class="img-fluid shadow shadow-md w-100" style="height: 224px; object-fit: cover;">
                    </figure>
                    <h3 class="text-uppercase text-blue mt-3 mb-0 h5 mb-5">Video Editing</h3>
                </div>
            </a>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal4db819f0f6bc03fb256e98b6ac2826d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4db819f0f6bc03fb256e98b6ac2826d4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.expbpo.home.whyChooseUs','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('expbpo.home.whyChooseUs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4db819f0f6bc03fb256e98b6ac2826d4)): ?>
<?php $attributes = $__attributesOriginal4db819f0f6bc03fb256e98b6ac2826d4; ?>
<?php unset($__attributesOriginal4db819f0f6bc03fb256e98b6ac2826d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4db819f0f6bc03fb256e98b6ac2826d4)): ?>
<?php $component = $__componentOriginal4db819f0f6bc03fb256e98b6ac2826d4; ?>
<?php unset($__componentOriginal4db819f0f6bc03fb256e98b6ac2826d4); ?>
<?php endif; ?>
</div>

</div>
<?php /**PATH D:\asif\nexusbpo\resources\views/components/expbpo/home/clients.blade.php ENDPATH**/ ?>
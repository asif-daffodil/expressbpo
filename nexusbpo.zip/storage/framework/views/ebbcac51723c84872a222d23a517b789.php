<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalb18af31d97ee6702edb129313bf17586 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb18af31d97ee6702edb129313bf17586 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.expbpo.home.slider','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('expbpo.home.slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb18af31d97ee6702edb129313bf17586)): ?>
<?php $attributes = $__attributesOriginalb18af31d97ee6702edb129313bf17586; ?>
<?php unset($__attributesOriginalb18af31d97ee6702edb129313bf17586); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb18af31d97ee6702edb129313bf17586)): ?>
<?php $component = $__componentOriginalb18af31d97ee6702edb129313bf17586; ?>
<?php unset($__componentOriginalb18af31d97ee6702edb129313bf17586); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalad2601b63c8eaa4eecd834c18e1d5439 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad2601b63c8eaa4eecd834c18e1d5439 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.expbpo.home.bannerBottom','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('expbpo.home.bannerBottom'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad2601b63c8eaa4eecd834c18e1d5439)): ?>
<?php $attributes = $__attributesOriginalad2601b63c8eaa4eecd834c18e1d5439; ?>
<?php unset($__attributesOriginalad2601b63c8eaa4eecd834c18e1d5439); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad2601b63c8eaa4eecd834c18e1d5439)): ?>
<?php $component = $__componentOriginalad2601b63c8eaa4eecd834c18e1d5439; ?>
<?php unset($__componentOriginalad2601b63c8eaa4eecd834c18e1d5439); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginaldf65de0fd5aee95084bfc7b385f24d2e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf65de0fd5aee95084bfc7b385f24d2e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.expbpo.home.trustedAccounting','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('expbpo.home.trustedAccounting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf65de0fd5aee95084bfc7b385f24d2e)): ?>
<?php $attributes = $__attributesOriginaldf65de0fd5aee95084bfc7b385f24d2e; ?>
<?php unset($__attributesOriginaldf65de0fd5aee95084bfc7b385f24d2e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf65de0fd5aee95084bfc7b385f24d2e)): ?>
<?php $component = $__componentOriginaldf65de0fd5aee95084bfc7b385f24d2e; ?>
<?php unset($__componentOriginaldf65de0fd5aee95084bfc7b385f24d2e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal01327501eb36a005c4cdec4d25b3b09d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal01327501eb36a005c4cdec4d25b3b09d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.expbpo.home.clients','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('expbpo.home.clients'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal01327501eb36a005c4cdec4d25b3b09d)): ?>
<?php $attributes = $__attributesOriginal01327501eb36a005c4cdec4d25b3b09d; ?>
<?php unset($__attributesOriginal01327501eb36a005c4cdec4d25b3b09d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01327501eb36a005c4cdec4d25b3b09d)): ?>
<?php $component = $__componentOriginal01327501eb36a005c4cdec4d25b3b09d; ?>
<?php unset($__componentOriginal01327501eb36a005c4cdec4d25b3b09d); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.express', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\asif\nexusbpo\resources\views/welcome.blade.php ENDPATH**/ ?>
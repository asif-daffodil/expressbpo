@extends('layouts.express')

@section('content')
    <x-expbpo.home.slider />
    <x-expbpo.home.bannerBottom />
    <x-expbpo.home.trustedAccounting />
    <x-expbpo.home.clients />
@endsection
